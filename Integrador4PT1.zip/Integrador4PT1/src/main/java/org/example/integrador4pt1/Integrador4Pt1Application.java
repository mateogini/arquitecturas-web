package org.example.integrador4pt1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Integrador4Pt1Application {

    public static void main(String[] args) {
        SpringApplication.run(Integrador4Pt1Application.class, args);
    }

}
