package org.example.micromantenimiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicromantenimientoApplicationTests {

    @Test
    void contextLoads() {
    }

}
